// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { Delete } from './pages/Delete';
import { Update } from './pages/Update';

class App extends React.Component {
  render() {

    // const data = getUserById(1);

    return (
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/deleteUser" element={<Delete />} />
          <Route path="/updateUser" element={<Update />} />
        </Routes>
      </BrowserRouter>
    );
  }
}

export { App };