// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';
import {Navbar} from '../components/Navbar';

class Delete extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>This is a route to a page named Delete Page</h1>
                <Navbar />
            </div>
        );
    }
};

export {Delete};