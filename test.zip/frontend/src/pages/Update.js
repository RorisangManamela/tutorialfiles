// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';
import {Navbar} from '../components/Navbar';

class Update extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>This a route to a page named Update</h1>
                <Navbar />
            </div>
        );
    }
};

export {Update};