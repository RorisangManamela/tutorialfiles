// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';

import {Navbar} from '../components/Navbar';
import {Posts} from '../components/Posts';

class Home extends React.Component {
    constructor(props) {
        super(props);
    }

    async getPosts() {

    }

    render() {
        return (
            <div>
                <h1>Home Page</h1>
                <Navbar />
                <Posts />
            </div>
        );
    }
};

export {Home};