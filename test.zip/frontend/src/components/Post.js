// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';
import {UpdatePost} from './updatePost';

class Post extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hidden: false
        }
    }

    toggleHidden() {
        this.setState({
            hidden: !this.state.hidden
        });
    }

    render() {
        return (
            <div>
                <h2>{this.props.name}</h2>
                <h3>{this.props.author.name}</h3>
                <ul>
                    {this.props.comments.map((commentObj, index) => {
                        <li key={index}>{commentObj.name} - {commentObj.comment}</li>
                    })}
                </ul>

                <button onClick={this.toggleHidden.bind(this)}>Update Post</button>
                {this.state.hidden && <UpdatePost name={this.props.name} author={this.props.author} comments={this.props.comments} />}

            </div>
        );
    }
};

export {Post};