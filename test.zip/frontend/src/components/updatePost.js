// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';

class UpdatePost extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            name: this.props.name,
            content: this.props.content,
            author: this.props.author,
            comments: this.props.comments
        }
        this.update = this.update.bind(this);
    }

    update() {

    }

    render() {
        return (
            <form onSubmit={this.update()}>
                <label>Name:</label>
                <input type="text" id="name" name="name" placeholder={this.state.name} required /><br /><br />


                <label>Content:</label>
                <input type="text" id="content" name="content" placeholder={this.state.content} required /><br /><br />

                <label>Author Name:</label>
                <input type="text" id="author" name="author" placeholder={this.state.author.name} required /><br /><br />

                {this.state.comments.map((comment, index) => {
                    <div id={index}>
                        <label>Commenter Name</label>
                        <input type="text" id="commenter" name="commenter" placeholder={comment.name} required /><br /><br />

                        <label>Comment</label>
                        <input type="text" id="comment" name="comment" placeholder={comment.comment} required /><br /><br />
                    </div>
                })}

                <input type="submit" value="Submit" />
            </form>
        );
    }
};

export {UpdatePost};