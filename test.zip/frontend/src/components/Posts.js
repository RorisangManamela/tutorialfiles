// Nicolaas Johan Jansen van Rensburg - u22590732

import React from 'react';

import {Post} from '../components/Post';

class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            posts: []
        }
        this.getPosts = this.getPosts.bind(this);
    }

    componentDidMount() {
        this.getPosts();
    }

    async getPosts() {
        const res = await fetch("http://localhost:3000/getUsers", {
            headers: {
                'Content-Type': 'application/json'
            },
            method: 'POST',
        });

        if (!res.ok) {
            throw new Error(`Response Status: ${res.status}`);
        }

        const result = await res.json();

        this.setState({
            posts: [...result]
        })
    }
    catch(error) {
        console.log(error);
    }

    render() {
        return (
            <div>
                {this.state.posts.map((post, index) => {
                    return (<Post key={index} name={post.name} author={post.author} comments={post.comments} />);
                })}
            </div>
        );
    }
};

export {Posts};